/*Write a program that displays your favorite poem. Use an appropriate escape sequence
for the line breaks. If you don’t have a favorite poem, you can borrow this one by Ogden
Nash:
Candy is dandy,
But liquor is quicker.*/

#include<iostream>

using namespace std;

int main(){
	cout << "Candy is dandy,\nBut liquor is quicker" << endl;
	return 0;
}
